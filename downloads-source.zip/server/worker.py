"""Web adaptation of GDownloader's multi-engine workflow. See ATTRIBUTION.md."""
import json
import re
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time
from urllib.parse import urlsplit
from zipfile import ZipFile, ZIP_DEFLATED
from yt_dlp import YoutubeDL
from safe_proxy import start_proxy

LIMIT = 250 * 1024 * 1024
RESULT_LIMIT = 500 * 1024 * 1024
AUDIO = {'mp3': ['libmp3lame', 'mp3'], 'm4a': ['aac', 'ipod'], 'wav': ['pcm_s16le', 'wav'],
         'flac': ['flac', 'flac'], 'opus': ['libopus', 'opus'], 'ogg': ['libvorbis', 'ogg']}
DEFAULTS = dict(engine='yt-dlp', resolution=1080, bitrate=192, fps=60, playlist=False, max_items=10,
                subtitles=False, automatic_subtitles=False, subtitle_language='es', thumbnail=False,
                metadata=True, description=False, hardware=False, rate_limit=0, retries=2)


def emit(**fields):
    print(json.dumps(fields), flush=True)


def ffmpeg(args):
    return subprocess.run([os.environ.get('FFMPEG_BINARY', '/usr/bin/ffmpeg'), '-nostdin', '-hide_banner', '-loglevel', 'error', '-y'] + args,
                          stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL).returncode


def local_input(path):
    return ['-protocol_whitelist', 'file,pipe', '-i', str(path)]


def transcode(source, output, fmt, settings, info, subtitle=None, cover=None):
    args = local_input(source)
    if subtitle and fmt in ('mp4', 'mkv', 'webm'):
        args += local_input(subtitle)
    if cover and fmt in ('mp3', 'm4a'):
        args += local_input(cover)
    args += ['-map_metadata', '-1', '-t', '1800', '-fs', str(LIMIT)]
    if settings['metadata']:
        for field, key in [('title', 'title'), ('artist', 'artist'), ('album', 'album')]:
            value = info.get(key) or (info.get('uploader') if key == 'artist' else '')
            if value:
                args += ['-metadata', f'{field}={str(value)[:500]}']
    if fmt in AUDIO:
        args += ['-map', '0:a:0', '-c:a', AUDIO[fmt][0]]
        if fmt not in ('wav', 'flac'):
            args += ['-b:a', f"{settings['bitrate']}k"]
        if cover and fmt in ('mp3', 'm4a'):
            args += ['-map', '1:v:0', '-c:v', 'mjpeg', '-disposition:v:0', 'attached_pic']
        else:
            args += ['-vn']
    else:
        encoder = os.environ.get('VIDEO_ENCODER', 'libx264') if settings['hardware'] else 'libx264'
        if encoder not in ('libx264', 'h264_nvenc', 'h264_qsv', 'h264_vaapi'):
            encoder = 'libx264'
        if fmt == 'webm':
            encoder = 'libvpx-vp9'
        args += ['-map', '0:v:0', '-map', '0:a:0?', '-vf', f"scale=-2:min({settings['resolution']}\\,trunc(ih/2)*2)",
                 '-c:v', encoder, '-threads', '2']
        if encoder == 'libx264':
            args += ['-preset', 'veryfast', '-crf', '23']
        elif encoder == 'libvpx-vp9':
            args += ['-deadline', 'realtime', '-cpu-used', '5', '-crf', '32', '-b:v', '0']
        args += ['-c:a', 'libopus' if fmt == 'webm' else 'aac', '-b:a', f"{settings['bitrate']}k"]
        if subtitle:
            args += ['-map', '1:s:0', '-c:s', 'mov_text' if fmt == 'mp4' else ('webvtt' if fmt == 'webm' else 'srt')]
        if fmt == 'mp4':
            args += ['-movflags', '+faststart']
    code = ffmpeg(args + [str(output)])
    if code and settings['hardware'] and fmt in ('mp4', 'mkv'):
        emit(state='converting', message='Aceleración no disponible; convirtiendo con CPU…', progress=None)
        return transcode(source, output, fmt, {**settings, 'hardware': False}, info, subtitle, cover)
    if code:
        raise ValueError('No se pudo convertir la pista elegida. Comprueba que el enlace contiene audio o video compatible.')
    if not output.exists() or not output.stat().st_size or output.stat().st_size >= LIMIT - 65536:
        raise ValueError('El resultado supera 250 MB. Elige menor calidad o un contenido más corto.')


def options_for(settings, directory, proxy_url, progress):
    def allowed(info, *, incomplete=False):
        if info.get('is_live') or info.get('live_status') == 'is_live':
            return 'Las transmisiones en vivo no están disponibles.'
        if info.get('has_drm'):
            return 'Este contenido está protegido.'
        if (info.get('duration') or 0) > 1800:
            return 'El límite por elemento es de 30 minutos.'
        if (info.get('filesize') or 0) > LIMIT:
            return 'El límite por elemento es de 250 MB.'
    protocol = '[protocol~="^(https?|m3u8_native|http_dash_segments)$"]'
    video = f"[height<={settings['resolution']}][fps<=?{settings['fps']}]"
    fmt = ('bestaudio' + protocol + '/best' + protocol) if settings['format'] in AUDIO else ('bestvideo' + video + protocol + '+bestaudio' + protocol + '/best' + video + protocol)
    return {'proxy': proxy_url, 'noplaylist': True, 'playlistend': 1, 'allowed_extractors': ['default', '-generic'],
            'outtmpl': str(directory / 'source.%(ext)s'), 'format': fmt, 'merge_output_format': 'mkv',
            'max_filesize': LIMIT, 'socket_timeout': 20, 'retries': settings['retries'], 'fragment_retries': settings['retries'],
            'ratelimit': settings['rate_limit'] * 1024 or None, 'concurrent_fragment_downloads': 1,
            'hls_prefer_native': True, 'match_filter': allowed, 'break_on_reject': True, 'progress_hooks': [progress],
            'quiet': True, 'no_warnings': True, 'cachedir': False, 'restrictfilenames': True,
            'ffmpeg_location': os.environ.get('SAFE_FFMPEG_DIR', '/app/bin'), 'js_runtimes': {'node': {}},
            'writesubtitles': settings['subtitles'], 'writeautomaticsub': settings['subtitles'] and settings['automatic_subtitles'],
            'subtitleslangs': settings['subtitle_language'].split(','), 'subtitlesformat': 'vtt/srt/best',
            'writethumbnail': settings['thumbnail'], 'writedescription': settings['description']}


def entries_for(url, settings, proxy_url):
    if not settings['playlist']:
        return [{'url': url}]
    options = dict(proxy=proxy_url, extract_flat='in_playlist', playlistend=settings['max_items'], lazy_playlist=True,
                   quiet=True, no_warnings=True, cachedir=False, socket_timeout=20, retries=settings['retries'],
                   allowed_extractors=['default', '-generic'], js_runtimes={'node': {}})
    with YoutubeDL(options) as ydl:
        info = ydl.extract_info(url, download=False)
        if not info:
            raise ValueError('No se pudo leer la lista.')
        entries = info.get('entries')
        if entries is None:
            return [{'url': url}]
        result = []
        for entry in entries:
            if not entry:
                continue
            link = entry.get('webpage_url') or entry.get('url')
            if not link or urlsplit(link).scheme not in ('http', 'https'):
                continue
            result.append({'url': link})
            if len(result) >= settings['max_items']:
                break
    if not result:
        raise ValueError('La lista no tiene elementos públicos disponibles.')
    return result


def spotify_entries(url, settings, proxy_url):
    config = {**settings, 'url': url, 'proxy': proxy_url}
    process = subprocess.run([os.environ.get('SPOTDL_PYTHON', '/opt/spotdl/bin/python'), str(Path(__file__).with_name('spotify_resolver.py'))],
                             input=json.dumps(config), text=True, stdout=subprocess.PIPE, stderr=subprocess.DEVNULL, timeout=300)
    lines = [line for line in process.stdout.splitlines() if line.startswith('OTW_RESULT=')]
    if process.returncode or not lines:
        raise ValueError('No se pudieron encontrar coincidencias para Spotify. El catálogo o la búsqueda no están disponibles.')
    entries = json.loads(lines[-1].split('=', 1)[1])
    if not entries:
        raise ValueError('No se encontró una coincidencia pública en YouTube para ese enlace de Spotify.')
    return entries


def gallery(url, settings, directory, proxy_url):
    from gallery_dl import config, job, exception
    config.clear()
    config.set(('extractor',), 'base-directory', str(directory))
    config.set(('extractor',), 'directory', [])
    config.set(('extractor',), 'filename', '{otw_index:>04}.{extension}')
    config.set(('extractor',), 'proxy', proxy_url)
    config.set(('extractor',), 'timeout', 20)
    config.set(('extractor',), 'retries', settings['retries'])
    config.set(('extractor',), 'image-range', f"1-{settings['max_items']}")
    config.set(('downloader', 'http'), 'filesize-max', LIMIT)
    config.set(('downloader', 'http'), 'rate', settings['rate_limit'] * 1024 or None)
    config.set(('output',), 'mode', 'null')
    count = 0
    class GalleryJob(job.DownloadJob):
        def handle_url(self, resource_url, data):
            nonlocal count
            if count >= settings['max_items']:
                raise exception.StopExtraction(128)
            if str(data.get('extension', '')).lower() not in ('jpg', 'jpeg', 'png', 'webp', 'gif', 'avif'):
                return
            count += 1
            data['otw_index'] = count
            emit(state='downloading', message=f"Galería · imagen {count}", progress=None, count=count)
            super().handle_url(resource_url, data)
    GalleryJob(url).run()
    files = [p for p in directory.iterdir() if p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp', '.gif', '.avif')]
    if not files:
        raise ValueError('No se encontraron imágenes públicas compatibles en la galería.')
    return files


def package(files, directory):
    total = sum(p.stat().st_size for p in files)
    if total > RESULT_LIMIT:
        raise ValueError('El lote supera 500 MB. Reduce los elementos o la calidad.')
    if len(files) == 1 and files[0].name != 'metadata.json':
        ext = files[0].suffix.lstrip('.')
        shutil.move(str(files[0]), directory / ('result.' + ext))
    else:
        ext = 'zip'
        with ZipFile(directory / 'result.zip', 'w', ZIP_DEFLATED) as archive:
            for path in files:
                archive.write(path, path.relative_to(directory))
        if (directory / 'result.zip').stat().st_size > RESULT_LIMIT:
            raise ValueError('El paquete supera 500 MB.')
    return ext


def run(url, output_format, directory, settings=None):
    settings = {**DEFAULTS, **(settings or {}), 'format': output_format}
    proxy, proxy_url = start_proxy()
    files, warnings, manifest = [], [], []
    try:
        emit(state='checking', message='Comprobando el enlace…', progress=None)
        if settings['engine'] == 'gallery-dl':
            images = directory / 'galeria'
            images.mkdir()
            files = gallery(url, settings, images, proxy_url)
            # Galleries always arrive in a ZIP, including a one-image gallery.
            manifest = [{'source': url, 'images': len(files)}]
            (directory / 'metadata.json').write_text(json.dumps(manifest, ensure_ascii=False))
            files.append(directory / 'metadata.json')
            count = len(files) - 1
            title = 'Galería'
        else:
            entries = spotify_entries(url, settings, proxy_url) if settings['engine'] == 'spotdl' else entries_for(url, settings, proxy_url)
            count = 0
            title = 'Descargas'
            for index, entry in enumerate(entries, 1):
                item = directory / f'{index:02d}'
                item.mkdir()
                last = [0]
                def progress(data):
                    if data.get('downloaded_bytes', 0) > LIMIT:
                        raise ValueError('El archivo supera 250 MB')
                    if time.monotonic() - last[0] < .5:
                        return
                    last[0] = time.monotonic()
                    total = data.get('total_bytes') or data.get('total_bytes_estimate')
                    percent = min(99, ((index-1) + data.get('downloaded_bytes', 0) / total) / len(entries) * 100) if total else None
                    emit(state='downloading', progress=percent, count=count, speed=data.get('speed'), eta=data.get('eta'), message=f'Descargando {index} de {len(entries)}…')
                try:
                    with YoutubeDL(options_for(settings, item, proxy_url, progress)) as ydl:
                        info = ydl.extract_info(entry['url'], download=True)
                    if not info or info.get('_type') in ('playlist', 'multi_video'):
                        raise ValueError('Activa la opción de lista para este enlace.')
                    info.update({k: v for k, v in entry.items() if k in ('title', 'artist', 'album') and v})
                    inputs = [p for p in item.glob('source.*') if p.suffix.lower() in ('.mp4', '.mkv', '.webm', '.m4a', '.mp3', '.ogg', '.opus', '.aac', '.flac', '.wav', '.mov', '.ts', '.flv')]
                    if len(inputs) != 1:
                        raise ValueError('No se pudo obtener una pista compatible.')
                    source = inputs[0]
                    subs = sorted(p for p in item.glob('source.*') if p.suffix in ('.vtt', '.srt'))
                    images = sorted(p for p in item.glob('source.*') if p.suffix.lower() in ('.jpg', '.jpeg', '.png', '.webp'))
                    cover = None
                    if images:
                        candidate = item / 'caratula.jpg'
                        if ffmpeg(local_input(images[0]) + ['-frames:v', '1', str(candidate)]) == 0:
                            cover = candidate
                            files.append(cover)
                    if settings['subtitles'] and not subs:
                        warnings.append(f'{index}: No hay subtítulos disponibles en el idioma elegido.')
                    if settings['thumbnail'] and not cover:
                        warnings.append(f'{index}: No hay carátula disponible.')
                    title = info.get('title') or 'Archivo'
                    emit(state='converting', title=title[:200], progress=None, message=f'Convirtiendo {index} de {len(entries)}…')
                    outputs = ('mp4', 'mp3') if output_format == 'both' else (output_format,)
                    item_results = []
                    for fmt in outputs:
                        result = item / ('archivo.' + fmt)
                        transcode(source, result, fmt, settings, info, subs[0] if subs else None, cover)
                        item_results.append(result)
                    files += item_results + subs + list(item.glob('*.description'))
                    source.unlink()
                    manifest.append({'title': title, 'source': entry['url'], 'original_link': url, 'artist': info.get('artist') or info.get('uploader'), 'album': info.get('album'), 'engine': settings['engine']})
                    count += 1
                except Exception as exc:
                    if len(entries) == 1:
                        raise
                    warnings.append(f'{index}: ' + (str(exc) if isinstance(exc, ValueError) else 'No se pudo descargar este elemento.'))
                if sum(p.stat().st_size for p in files if p.exists()) > RESULT_LIMIT:
                    raise ValueError('El lote supera 500 MB. Reduce los elementos o la calidad.')
            if count == 0:
                raise ValueError('No se pudo descargar ningún elemento del lote.')
            if settings['playlist'] or settings['engine'] == 'spotdl':
                meta = directory / 'metadata.json'
                meta.write_text(json.dumps(manifest, ensure_ascii=False, indent=2))
                files.append(meta)
        if warnings:
            note = directory / 'avisos.txt'
            note.write_text('\n'.join(warnings))
            files.append(note)
        ext = package(files, directory)
        for path in list(directory.iterdir()):
            if path.name == 'result.' + ext:
                continue
            if path.is_dir():
                shutil.rmtree(path)
            else:
                path.unlink()
        emit(state='ready', progress=100, result_ext=ext, count=count, title=title[:200] if count == 1 else f'Lote de {count} elementos',
             message=f'{count} elemento(s) listo(s). Disponible 30 minutos.' + (' Consulta avisos.txt en el ZIP.' if warnings else ''))
    finally:
        proxy.shutdown()
        proxy.server_close()


if __name__ == '__main__':
    try:
        request_path = Path(sys.argv[1])
        options = json.loads(request_path.read_text())
        run(options['url'], options['format'], request_path.parent, options)
    except Exception as exc:
        detail = str(exc)
        print(type(exc).__name__ + ': ' + re.sub(r'https?://\S+', '[URL]', detail)[:1500], file=sys.stderr)
        if 'confirm you' in detail.lower() or 'not a bot' in detail.lower():
            message = 'YouTube bloqueó la descarga desde este servidor y solicita verificar la sesión. No se pudo obtener el archivo.'
        elif 'requested format' in detail.lower():
            message = 'La plataforma no ofrece una pista compatible con la calidad seleccionada. Prueba otra calidad.'
        else:
            message = str(exc) if isinstance(exc, ValueError) else 'No se pudo descargar: enlace no compatible, contenido restringido o plataforma temporalmente no disponible.'
        emit(state='error', progress=None, message=message)
        sys.exit(1)
