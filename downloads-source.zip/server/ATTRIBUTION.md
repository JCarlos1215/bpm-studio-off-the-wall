# Créditos y alcance

Referencia solicitada: [GDownloader](https://github.com/hstr0100/GDownloader), autor hstr0100 / Gabriel / vertx010, GPL-3.0-or-later. Revisión estudiada: `f78416a13170037e76537fe01729b9b89ca5ff8f`.

Esta es una adaptación independiente para navegador y servidor de su flujo de descargas. No ejecuta ni incluye la aplicación Java de GDownloader. Los nuevos módulos del gestor se distribuyen bajo GPL-3.0-or-later; se incluye el texto de la licencia en LICENSE. La marca Off The Wall y el logo aportado por el usuario no se relicencian.

Motores utilizados y sus licencias propias:
- yt-dlp: https://github.com/yt-dlp/yt-dlp (Unlicense; sus dependencias tienen licencias propias).
- gallery-dl: https://github.com/mikf/gallery-dl (GPL-2.0; consultar la licencia y avisos de su distribución).
- spotDL: https://github.com/spotDL/spotify-downloader (MIT).
- FFmpeg: https://ffmpeg.org/legal.html (la distribución y los códecs habilitados determinan sus obligaciones LGPL/GPL).

Los motores se instalan desde sus paquetes oficiales durante la construcción de Docker. No se incluyen sus binarios en el ZIP de fuentes del gestor. Sus repositorios proporcionan código y licencias correspondientes.

## Correspondencia funcional

| GDownloader | Adaptación web |
|---|---|
| Añadir enlaces y descargas en lote | Pegar múltiples enlaces, arrastrar/importar TXT/JSON, exportar la cola, deduplicar |
| Cola de descargas | Dos trabajos simultáneos como máximo, priorizar, filtrar, buscar, ordenar, cancelar, reintentar y limpiar |
| Pausa y restauración | Pausa de los siguientes trabajos; los activos continúan. Guardado opcional en el navegador; reconexión automática |
| yt-dlp | Audio, video, audio+video, listas limitadas, resolución/FPS, bitrate, subtítulos, carátula y descripción |
| gallery-dl | Galerías de imágenes en ZIP, hasta 20 elementos; no todos los tipos de archivo de gallery-dl |
| spotDL | Metadatos de Spotify y coincidencias en YouTube; el audio no procede de Spotify. Se procesan con los mismos límites de yt-dlp |
| Formatos | MP3, M4A, WAV, FLAC, Opus, OGG, MP4, MKV, WebM, MP4+MP3 ZIP y galerías ZIP |
| Subtítulos y carátulas | Primer subtítulo incrustado en video, todos los subtítulos disponibles seleccionados en ZIP; carátula en archivo e incrustada en MP3/M4A |
| Metadatos | Título, artista y álbum si están disponibles; manifiesto de procedencia en listas y coincidencias Spotify |
| Aceleración de video | Preferencia de servidor mediante VIDEO_ENCODER; fallback CPU. No utiliza la GPU del teléfono |
| Reintentos y velocidad | Ajustes por trabajo, reintento manual del trabajo completo; no es un limitador global de ancho de banda |
| Historial | Cola finalizada guardada opcionalmente en este navegador; no es un historial de cuenta entre dispositivos |
| Actualizaciones automáticas / instalación FFmpeg | Dependencias fijadas y reconstrucción del contenedor por el administrador; no instaladores desde la web |
| Portapapeles continuo / atajo global | Botón de pegar o pegar dentro del cuadro; sin vigilancia global del sistema |
| Bandeja, inicio del sistema, ventanas, carpetas locales | Se sustituyen por pestaña responsive y descargas del navegador |

## Funciones NO portadas

No se ofrece equivalencia total con todas las opciones de escritorio. No están implementados: captura global del portapapeles, lectura de cookies del navegador, importación de cookies, argumentos arbitrarios de ejecutables, proxies personalizados por usuario, SponsorBlock, mezcla de todas las pistas de audio, ajustes de codificación expertos por plataforma, sincronización de carpetas, archivos originales adicionales, autoactualización en ejecución, avisos del sistema/sonidos, magnet links ni integración con la bandeja del sistema. No se admiten directos ni DRM.

La publicación del servidor sigue pendiente; instalar los motores no garantiza que cada plataforma acepte el alojamiento. La página identifica este estado y permite organizar la cola sin fingir una descarga.
