import base64
import io
import re
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
import requests
from urllib3.response import HTTPResponse
from gallery_dl.extractor.common import Extractor, Message
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from worker import gallery, DEFAULTS

class GalleryTests(unittest.TestCase):
 def test_actual_gallery_pipeline_with_controlled_image(self):
  png=base64.b64decode('iVBORw0KGgoAAAANSUhEUgAAAAEAAAABCAQAAAC1HAwCAAAAC0lEQVR42mP8/x8AAwMCAO+aCrkAAAAASUVORK5CYII=')
  class FixtureExtractor(Extractor):
   category='fixture'
   subcategory='image'
   def items(self):
    yield Message.Directory, '', {'id':'fixture'}
    yield Message.Url, 'https://example.com/fixture.png', {'extension':'png','filename':'fixture'}
  def response(*args,**kwargs):
   result=requests.Response();result.status_code=200;result.url='https://example.com/fixture.png';result.headers={'Content-Length':str(len(png)),'Content-Type':'image/png'};result.raw=HTTPResponse(body=io.BytesIO(png),preload_content=False);return result
  with tempfile.TemporaryDirectory() as tmp, patch('gallery_dl.extractor.find',side_effect=lambda url:FixtureExtractor(re.match('.*',url))), patch('requests.sessions.Session.request',side_effect=response):
   files=gallery('https://example.com/gallery',DEFAULTS,Path(tmp),'http://127.0.0.1:1234')
   self.assertEqual(len(files),1)
   self.assertEqual(files[0].read_bytes(),png)

if __name__=='__main__':unittest.main()
