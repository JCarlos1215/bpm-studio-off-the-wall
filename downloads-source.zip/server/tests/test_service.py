import os
from pathlib import Path
import socket
import sys
import time
import unittest
from unittest.mock import patch

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
os.environ['DOWNLOAD_PASSWORD'] = 'test-only-private-password'
from fastapi.testclient import TestClient
import server
from safe_proxy import public_addresses

client = TestClient(server.app)
AUTH = {'Authorization': 'Bearer ' + os.environ['DOWNLOAD_PASSWORD']}


class ServiceTests(unittest.TestCase):
    def test_auth(self):
        self.assertEqual(client.post('/jobs', json={'url': 'https://example.com/a', 'format': 'mp3'}).status_code, 401)
        self.assertEqual(client.get('/jobs/a', headers={'Authorization': 'Bearer incorrect'}).status_code, 401)

    def test_invalid_urls_and_spotify(self):
        for url in ['file:///etc/passwd', 'http://127.0.0.1/a', 'http://[::1]/', 'http://169.254.169.254/', 'https://user:pass@example.com', 'http://[::ffff:127.0.0.1]/']:
            self.assertEqual(client.post('/jobs', headers=AUTH, json={'url': url, 'format': 'mp3'}).status_code, 422, url)

    def test_dns_mixed_public_private(self):
        values = [(socket.AF_INET, socket.SOCK_STREAM, 6, '', (ip, 443)) for ip in ['8.8.8.8', '10.0.0.1']]
        with patch('socket.getaddrinfo', return_value=values):
            with self.assertRaises(ValueError):
                public_addresses('example.com', 443)

    def test_format_rejected(self):
        self.assertEqual(client.post('/jobs', headers=AUTH, json={'url': 'https://example.com/a', 'format': 'mp4;ls'}).status_code, 422)

    def test_cors(self):
        for origin, expected in [(server.ORIGIN, 200), ('https://untrusted.example', 400)]:
            result = client.options('/jobs', headers={'Origin': origin, 'Access-Control-Request-Method': 'POST', 'Access-Control-Request-Headers': 'Authorization'})
            self.assertEqual(result.status_code, expected)

    def test_lifecycle_and_file(self):
        with patch('server.validate_url', return_value='https://example.com/a'), patch('server.execute'):
            result = client.post('/jobs', headers=AUTH, json={'url': 'https://example.com/a', 'format': 'mp3'})
        self.assertEqual(result.status_code, 202)
        key = result.json()['id']
        server.SLOTS.release()  # mocked worker owns no slot
        self.assertEqual(client.get('/files/' + key).status_code, 409)
        job = server.JOBS[key]
        job.update(state='ready', title='Test', finished=time.time())
        (job['directory'] / 'result.mp3').write_bytes(b'test-file')
        response = client.get('/files/' + key)
        self.assertEqual(response.content, b'test-file')
        self.assertIn('attachment', response.headers['content-disposition'])
        self.assertEqual(client.delete('/jobs/' + key, headers=AUTH).status_code, 200)
        self.assertFalse(job['directory'].exists())
        self.assertEqual(client.get('/jobs/' + key, headers=AUTH).json()['state'], 'cancelled')
        job['finished'] -= 1801
        server.sweep()
        self.assertEqual(client.get('/jobs/' + key, headers=AUTH).status_code, 404)

    def test_public_mode_without_password(self):
        with patch.object(server, 'PUBLIC_DOWNLOADS', True):
            self.assertEqual(client.get('/capabilities', headers={'Origin':server.ORIGIN}).status_code,200)
            self.assertEqual(client.get('/capabilities', headers={'Origin':'https://other.example'}).status_code,403)
            server.PUBLIC_QUOTAS['testclient'] = server.deque([time.time()] * 20)
            response=client.post('/jobs',headers={'Origin':server.ORIGIN},json={'url':'https://example.com/a','format':'mp3'})
            self.assertEqual(response.status_code,429)
            server.PUBLIC_QUOTAS.clear()

    def test_timeout(self):
        directory = server.ROOT / 'timeout-test'
        directory.mkdir(exist_ok=True)
        server.JOBS['timeout-test'] = dict(state='downloading', directory=directory, created=time.time()-1201)
        server.sweep()
        self.assertEqual(server.JOBS['timeout-test']['state'], 'error')
        server.JOBS['timeout-test']['finished'] -= 1801
        server.sweep()
        self.assertFalse(directory.exists())


if __name__ == '__main__':
    unittest.main()
