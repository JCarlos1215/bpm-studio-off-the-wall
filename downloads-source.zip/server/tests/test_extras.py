import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from worker import transcode, DEFAULTS
FFMPEG=os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')

@unittest.skipUnless(FFMPEG,'Requires FFmpeg')
class ExtraTests(unittest.TestCase):
 def test_subtitles_cover_and_metadata(self):
  with tempfile.TemporaryDirectory() as tmp:
   root=Path(tmp);source=root/'source.mp4';cover=root/'cover.jpg';subtitle=root/'subtitle.srt'
   subprocess.run([FFMPEG,'-v','error','-f','lavfi','-i','color=blue:size=160x90:rate=10','-f','lavfi','-i','sine=frequency=440','-t','1','-c:v','libx264','-c:a','aac',str(source)],check=True)
   subprocess.run([FFMPEG,'-v','error','-f','lavfi','-i','color=red:size=64x64','-frames:v','1',str(cover)],check=True)
   subtitle.write_text('1\n00:00:00,000 --> 00:00:00,800\nPrueba original\n')
   for fmt in ('mp4','mp3','m4a'):
    output=root/('out.'+fmt)
    transcode(source,output,fmt,DEFAULTS,{'title':'Fixture title','artist':'Fixture artist'},subtitle,cover)
    info=subprocess.run([FFMPEG,'-hide_banner','-i',str(output)],capture_output=True,text=True).stderr
    self.assertIn('Fixture title',info)
    self.assertIn('Subtitle: mov_text' if fmt=='mp4' else 'attached pic',info)

if __name__=='__main__':unittest.main()
