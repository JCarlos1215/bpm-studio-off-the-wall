import io
import json
import os
from pathlib import Path
import sys
import tempfile
import unittest
from unittest.mock import patch
from types import SimpleNamespace
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import worker
import spotify_resolver
os.environ.setdefault('DOWNLOAD_PASSWORD','test-only-private-password')
import server
from fastapi import HTTPException


class EngineTests(unittest.TestCase):
    def test_options(self):
        settings = {**worker.DEFAULTS, 'format':'mp4', 'resolution':2160, 'subtitles':True, 'automatic_subtitles':True, 'thumbnail':True, 'rate_limit':200, 'retries':4}
        args = worker.options_for(settings, Path('/tmp/fixture'), 'http://127.0.0.1:1234', lambda _: None)
        self.assertIn('height<=2160', args['format'])
        self.assertEqual(args['ratelimit'],204800)
        self.assertTrue(args['writesubtitles'])
        self.assertTrue(args['writeautomaticsub'])
        self.assertTrue(args['writethumbnail'])
        self.assertEqual(args['retries'],4)
        self.assertIsNotNone(args['match_filter']({'duration':1801}))
        self.assertIsNotNone(args['match_filter']({'has_drm':True}))

    def test_spotify_matches_not_original_audio(self):
        class FakeSpotdl:
            def __init__(self, **kwargs):
                self.downloader = SimpleNamespace(search=lambda song:'https://www.youtube.com/watch?v=fixture')
            def search(self, query):
                return [SimpleNamespace(name='Fixture', artists=['Artist'], album_name='Album')]
        with patch.dict(sys.modules, {'spotdl':SimpleNamespace(Spotdl=FakeSpotdl)}), patch.dict(os.environ):
            result=spotify_resolver.resolve({'url':'https://open.spotify.com/track/fixture','proxy':'http://127.0.0.1:1234','playlist':False,'max_items':2})
        self.assertEqual(result[0]['artist'],'Artist')
        self.assertIn('youtube.com',result[0]['url'])

    def test_spotify_rejects_non_youtube_result(self):
        class FakeSpotdl:
            def __init__(self, **kwargs):
                self.downloader = SimpleNamespace(search=lambda song:'http://127.0.0.1/internal')
            def search(self, query):
                return [SimpleNamespace()]
        with patch.dict(sys.modules, {'spotdl':SimpleNamespace(Spotdl=FakeSpotdl)}), patch.dict(os.environ):
            result=spotify_resolver.resolve({'url':'https://open.spotify.com/track/fixture','proxy':'http://127.0.0.1:1234','playlist':False,'max_items':2})
        self.assertEqual(result,[])

    def test_engine_validation(self):
        self.assertEqual(server.resolve_engine(server.Request(url='https://example.com/gallery',format='gallery')),'gallery-dl')
        with self.assertRaises(HTTPException):
            server.resolve_engine(server.Request(url='https://example.com/a',engine='spotdl',format='mp3'))
        with self.assertRaises(HTTPException):
            server.resolve_engine(server.Request(url='https://example.com/a',engine='gallery-dl',format='mp4'))

    def test_package_limits(self):
        with tempfile.TemporaryDirectory() as tmp:
            directory=Path(tmp)
            a=directory/'audio.mp3';a.write_bytes(b'abc')
            b=directory/'subtitles.srt';b.write_text('subtitle')
            self.assertEqual(worker.package([a,b],directory),'zip')
            with patch.object(worker,'RESULT_LIMIT',1):
                with self.assertRaises(ValueError):worker.package([a,b],directory)


if __name__=='__main__':unittest.main()
