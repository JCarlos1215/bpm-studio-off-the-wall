"""Real FFmpeg conversion using an original synthetic fixture (no platform download)."""
import contextlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import tempfile
import unittest
from unittest.mock import patch
sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
import worker

FFMPEG = os.environ.get('FFMPEG_BINARY') or shutil.which('ffmpeg')


@unittest.skipUnless(FFMPEG, 'Set FFMPEG_BINARY to run real MP3/MP4 conversion tests')
class ConversionTests(unittest.TestCase):
    def test_real_mp3_and_mp4(self):
        class FixtureSource:
            def __init__(self, options):
                self.options = options
            def __enter__(self):
                return self
            def __exit__(self, *args):
                pass
            def extract_info(self, url, download):
                path = self.options['outtmpl'].replace('%(ext)s', 'mp4')
                subprocess.run([FFMPEG, '-nostdin', '-v', 'error', '-f', 'lavfi', '-i', 'color=blue:size=160x90:rate=10', '-f', 'lavfi', '-i', 'sine=frequency=440:sample_rate=44100', '-t', '1', '-c:v', 'libx264', '-c:a', 'aac', path], check=True)
                return {'title': 'Original test fixture', 'duration': 1}
        for fmt in ['mp3', 'm4a', 'wav', 'flac', 'opus', 'ogg', 'mp4', 'mkv', 'webm', 'both']:
            with self.subTest(format=fmt), tempfile.TemporaryDirectory() as tmp:
                logs = io.StringIO()
                with patch.object(worker, 'YoutubeDL', FixtureSource), patch.dict(os.environ, {'FFMPEG_BINARY': FFMPEG}), contextlib.redirect_stdout(logs):
                    worker.run('https://example.com/test', fmt, Path(tmp))
                result = Path(tmp) / ('result.zip' if fmt == 'both' else f'result.{fmt}')
                self.assertGreater(result.stat().st_size, 1000)
                self.assertEqual(json.loads(logs.getvalue().splitlines()[-1])['state'], 'ready')
                if fmt != 'both':
                    subprocess.run([FFMPEG, '-v', 'error', '-i', str(result), '-f', 'null', '-'], check=True)
                else:
                    from zipfile import ZipFile
                    with ZipFile(result) as z:
                        self.assertEqual(set(z.namelist()), {'01/archivo.mp4', '01/archivo.mp3'})


if __name__ == '__main__':
    unittest.main()
