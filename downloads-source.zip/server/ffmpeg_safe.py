#!/usr/bin/env python3
"""Force FFmpeg/ffprobe inputs to local file protocols, including HLS fallback."""
import os
from pathlib import Path
import sys

name = Path(sys.argv[0]).name
args = sys.argv[1:]
checked = []
for arg in args:
    if arg == '-i':
        checked += ['-protocol_whitelist', 'file,pipe']
    checked.append(arg)
if name == 'ffprobe':
    checked = ['-protocol_whitelist', 'file,pipe'] + checked
os.execv('/usr/bin/' + name, [name] + checked)
