"""Loopback-only outbound proxy: resolve once, reject nonpublic IPs, connect to that IP."""
import http.server
import ipaddress
import select
import socket
import threading
from urllib.parse import urlsplit


def public_addresses(host, port):
    addresses = socket.getaddrinfo(host, port, type=socket.SOCK_STREAM)
    if not addresses or any(not ipaddress.ip_address(a[4][0]).is_global for a in addresses):
        raise ValueError('Destino de red no permitido')
    return addresses


def connect_public(host, port):
    if port not in (80, 443):
        raise ValueError('Puerto no permitido')
    addresses = public_addresses(host, port)
    for family, kind, proto, _, address in addresses:
        sock = socket.socket(family, kind, proto)
        sock.settimeout(20)
        try:
            sock.connect(address)
            return sock
        except OSError:
            sock.close()
    raise OSError('No se pudo conectar')


class Handler(http.server.BaseHTTPRequestHandler):
    def log_message(self, *args):
        pass

    def do_CONNECT(self):
        try:
            target = urlsplit('//' + self.path)
            if target.username or target.password:
                raise ValueError('Credenciales no permitidas')
            with connect_public(target.hostname, target.port or 443) as upstream:
                self.send_response(200)
                self.end_headers()
                while True:
                    ready, _, _ = select.select([self.connection, upstream], [], [], 30)
                    if not ready:
                        break
                    for source in ready:
                        data = source.recv(65536)
                        if not data:
                            return
                        (upstream if source is self.connection else self.connection).sendall(data)
        except (ValueError, OSError):
            self.close_connection = True

    def forward(self):
        try:
            target = urlsplit(self.path)
            if target.scheme != 'http' or target.username or target.password:
                raise ValueError('URL no permitida')
            if self.headers.get('Transfer-Encoding'):
                raise ValueError('Transferencia no permitida')
            length = int(self.headers.get('Content-Length', '0'))
            if length < 0 or length > 1024 * 1024:
                raise ValueError('Solicitud demasiado grande')
            with connect_public(target.hostname, target.port or 80) as upstream:
                path = (target.path or '/') + ('?' + target.query if target.query else '')
                headers = {k: v for k, v in self.headers.items() if k.lower() not in
                           ('host', 'connection', 'proxy-connection', 'proxy-authorization')}
                headers.update({'Host': target.netloc, 'Connection': 'close'})
                request = f'{self.command} {path} HTTP/1.1\r\n' + ''.join(f'{k}: {v}\r\n' for k, v in headers.items()) + '\r\n'
                upstream.sendall(request.encode('latin-1'))
                if length:
                    upstream.sendall(self.rfile.read(length))
                while data := upstream.recv(65536):
                    self.connection.sendall(data)
                self.close_connection = True
        except (ValueError, OSError):
            self.close_connection = True

    do_GET = do_HEAD = do_POST = forward


def start_proxy():
    server = http.server.ThreadingHTTPServer(('127.0.0.1', 0), Handler)
    threading.Thread(target=server.serve_forever, daemon=True).start()
    return server, f'http://127.0.0.1:{server.server_port}'
