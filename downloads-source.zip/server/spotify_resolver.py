"""spotDL metadata/matching only. Media is fetched by the bounded yt-dlp worker."""
import json
import os
import sys
from urllib.parse import urlsplit


def resolve(data):
    for name in ('HTTP_PROXY', 'HTTPS_PROXY', 'ALL_PROXY', 'http_proxy', 'https_proxy', 'all_proxy'):
        os.environ[name] = data['proxy']
    os.environ['NO_PROXY'] = os.environ['no_proxy'] = ''
    from spotdl import Spotdl
    client = Spotdl(client_id=os.environ.get('SPOTIFY_CLIENT_ID', ''), client_secret=os.environ.get('SPOTIFY_CLIENT_SECRET', ''),
                    headless=True, no_cache=True, use_official_api=bool(os.environ.get('SPOTIFY_CLIENT_ID')),
                    downloader_settings={'threads': 1, 'proxy': data['proxy'], 'audio_providers': ['youtube'],
                                         'ffmpeg': os.environ.get('FFMPEG_BINARY', '/usr/bin/ffmpeg'),
                                         'yt_dlp_args': {'proxy': data['proxy'], 'socket_timeout': 20, 'js_runtimes': {'node': {}}}})
    songs = client.search([data['url']])
    if len(songs) > 1 and not data['playlist']:
        raise ValueError('Activa las listas para este enlace.')
    result = []
    for song in songs[:data['max_items'] if data['playlist'] else 1]:
        url = client.downloader.search(song)
        host = urlsplit(url).hostname if url else None
        if host and (host == 'youtu.be' or host == 'youtube.com' or host.endswith('.youtube.com')):
            result.append({'url': url, 'title': song.name, 'artist': ', '.join(song.artists), 'album': song.album_name})
    return result


if __name__ == '__main__':
    print('OTW_RESULT=' + json.dumps(resolve(json.load(sys.stdin)), ensure_ascii=False))
