import hmac
import json
import os
from pathlib import Path
import re
import secrets
import shutil
import signal
import subprocess
import sys
import tempfile
import threading
import time
from urllib.parse import urlsplit

from fastapi import Depends, FastAPI, Header, HTTPException, Request as HttpRequest
from collections import defaultdict, deque
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field, ConfigDict
from typing import Literal
import importlib.metadata
from safe_proxy import public_addresses

SECRET = os.environ.get('DOWNLOAD_PASSWORD', '')
if len(SECRET) < 16:
    raise RuntimeError('Set DOWNLOAD_PASSWORD to a private password of at least 16 characters.')
ORIGIN = os.environ.get('APP_ORIGIN', 'https://clinquant-kelpie-5cea2b.netlify.app').rstrip('/')
ROOT = Path(tempfile.mkdtemp(prefix='otw-downloads-'))
JOBS = {}
LOCK = threading.RLock()
MAX_PARALLEL = max(1, min(2, int(os.environ.get('MAX_PARALLEL', '1'))))
SLOTS = threading.BoundedSemaphore(MAX_PARALLEL)
TERMINAL = {'ready', 'error', 'cancelled'}
app = FastAPI(docs_url=None, redoc_url=None, openapi_url=None)
app.add_middleware(CORSMiddleware, allow_origins=[ORIGIN], allow_methods=['GET', 'POST', 'DELETE'], allow_headers=['Authorization', 'Content-Type'])


PUBLIC_DOWNLOADS = os.environ.get('PUBLIC_DOWNLOADS') == '1'
PUBLIC_QUOTAS = defaultdict(deque)

def authenticate(request: HttpRequest, authorization: str = Header(default='')):
    if PUBLIC_DOWNLOADS and not authorization:
        origin = request.headers.get('origin')
        if origin and origin != ORIGIN:
            raise HTTPException(403, 'Origen no autorizado.')
        return
    if not hmac.compare_digest(authorization.encode(), ('Bearer ' + SECRET).encode()):
        raise HTTPException(401, 'Clave de acceso incorrecta.')


class Request(BaseModel):
    model_config = ConfigDict(extra='forbid')
    url: str = Field(min_length=8, max_length=2048)
    format: Literal['mp3', 'm4a', 'wav', 'flac', 'opus', 'ogg', 'mp4', 'mkv', 'webm', 'both', 'gallery'] = 'mp4'
    engine: Literal['auto', 'yt-dlp', 'gallery-dl', 'spotdl'] = 'auto'
    resolution: Literal[480, 720, 1080, 1440, 2160] = 1080
    bitrate: Literal[128, 192, 256, 320] = 192
    fps: Literal[30, 60] = 60
    playlist: bool = False
    max_items: int = Field(default=10, ge=1, le=20)
    subtitles: bool = False
    automatic_subtitles: bool = False
    subtitle_language: Literal['es', 'en', 'es,en'] = 'es'
    thumbnail: bool = False
    metadata: bool = True
    description: bool = False
    hardware: bool = False
    rate_limit: int = Field(default=0, ge=0, le=10000)
    retries: int = Field(default=2, ge=0, le=5)


def resolve_engine(request):
    host = urlsplit(request.url).hostname or ''
    spotify = host == 'spotify.com' or host.endswith('.spotify.com') or host == 'spotify.link'
    engine = request.engine
    if engine == 'auto':
        engine = 'spotdl' if spotify else ('gallery-dl' if request.format == 'gallery' else 'yt-dlp')
    if engine == 'spotdl':
        if not spotify or request.format == 'gallery':
            raise HTTPException(422, 'Spotify requiere un enlace de Spotify y un formato de audio o video. Se descarga una coincidencia de YouTube.')
        if not Path(os.environ.get('SPOTDL_PYTHON', '/opt/spotdl/bin/python')).is_file():
            raise HTTPException(503, 'El motor spotDL todavía no está instalado en este servidor.')
    elif spotify:
        raise HTTPException(422, 'Selecciona el motor Spotify y un formato de audio.')
    if (engine == 'gallery-dl') != (request.format == 'gallery'):
        raise HTTPException(422, 'El motor de galerías requiere el formato Galería ZIP.')
    return engine


def validate_url(url):
    try:
        parsed = urlsplit(url)
        if parsed.scheme not in ('http', 'https') or not parsed.hostname or parsed.username or parsed.password or parsed.port not in (None, 80, 443):
            raise ValueError()
        if any(ord(c) < 32 for c in url):
            raise ValueError()
        public_addresses(parsed.hostname, parsed.port or (443 if parsed.scheme == 'https' else 80))
    except HTTPException:
        raise
    except (ValueError, OSError):
        raise HTTPException(422, 'Introduce un enlace público HTTP o HTTPS válido.')
    return url


def kill(job):
    proc = job.get('process')
    if proc and proc.poll() is None:
        try:
            os.killpg(proc.pid, signal.SIGKILL)
        except ProcessLookupError:
            pass


def execute(job):
    try:
        with LOCK:
            if job['state'] == 'cancelled':
                return
            proc = subprocess.Popen([sys.executable, '-u', str(Path(__file__).with_name('worker.py')), str(job['directory'] / 'request.json')],
                                    stdout=subprocess.PIPE, stderr=None, text=True, start_new_session=True)
            job['process'] = proc
        for line in proc.stdout:
            try:
                update = json.loads(line)
            except (ValueError, TypeError):
                continue
            with LOCK:
                if job['state'] in TERMINAL:
                    continue
                if update.get('state') in {'checking', 'downloading', 'converting', 'ready', 'error'}:
                    job.update({k: update[k] for k in ('state', 'progress', 'message', 'title', 'result_ext', 'count', 'speed', 'eta') if k in update})
                    if job['state'] in TERMINAL:
                        job['finished'] = time.time()
        proc.wait()
        with LOCK:
            if job['state'] not in TERMINAL or (proc.returncode and job['state'] == 'ready'):
                job.update(state='error', message='El proceso se interrumpió. Inténtalo de nuevo.', finished=time.time())
    except Exception:
        with LOCK:
            job.update(state='error', message='No se pudo iniciar la descarga.', finished=time.time())
    finally:
        if job['state'] != 'ready':
            shutil.rmtree(job['directory'], ignore_errors=True)
        SLOTS.release()


def sweep():
    with LOCK:
        for key, job in list(JOBS.items()):
            if job['state'] not in TERMINAL:
                size = 0
                for path in job['directory'].rglob('*'):
                    try:
                        size += path.stat().st_size
                    except FileNotFoundError:
                        pass
                if time.time() - job['created'] > 1200 or size > 1200 * 1024 * 1024:
                    job.update(state='error', message='Se alcanzó el límite de tiempo o tamaño. Usa un contenido más corto.', finished=time.time())
                    kill(job)
            elif time.time() - job.get('finished', job['created']) > 1800:
                shutil.rmtree(job['directory'], ignore_errors=True)
                del JOBS[key]


def housekeeping():
    while True:
        time.sleep(1)
        sweep()


@app.get('/health')
def health():
    return {'status': 'ok'}


@app.get('/capabilities', dependencies=[Depends(authenticate)])
def capabilities():
    return {'engines': {'yt-dlp': True, 'gallery-dl': True, 'spotdl': Path(os.environ.get('SPOTDL_PYTHON', '/opt/spotdl/bin/python')).is_file()},
            'versions': {name: importlib.metadata.version(name) for name in ('yt-dlp', 'gallery-dl')},
            'hardware': os.environ.get('VIDEO_ENCODER', 'libx264') != 'libx264',
            'max_items': 20, 'max_parallel': MAX_PARALLEL, 'max_result_mb': 500, 'retention_minutes': 30}


@app.post('/jobs', dependencies=[Depends(authenticate)], status_code=202)
def create(request: Request, http_request: HttpRequest):
    if PUBLIC_DOWNLOADS and not http_request.headers.get('authorization'):
        address = http_request.client.host if http_request.client else 'unknown'
        now = time.time()
        with LOCK:
            for ip, timestamps in list(PUBLIC_QUOTAS.items()):
                while timestamps and now - timestamps[0] > 3600:
                    timestamps.popleft()
                if not timestamps:
                    del PUBLIC_QUOTAS[ip]
            if len(PUBLIC_QUOTAS) >= 10000 and address not in PUBLIC_QUOTAS:
                raise HTTPException(429, 'El servicio está ocupado. Intenta más tarde.')
            if len(PUBLIC_QUOTAS[address]) >= 20:
                raise HTTPException(429, 'Has alcanzado el límite de 20 solicitudes por hora.')
            PUBLIC_QUOTAS[address].append(now)
    url = validate_url(request.url.strip())
    engine = resolve_engine(request)
    with LOCK:
        if len(JOBS) >= 12 or not SLOTS.acquire(blocking=False):
            raise HTTPException(429, 'El servidor está ocupado. Espera unos minutos.')
        key = secrets.token_urlsafe(32)
        directory = ROOT / key
        directory.mkdir()
        job = dict(id=key, url=url, format=request.format, directory=directory, created=time.time(), state='checking', progress=None, message='Comprobando enlace…', engine=engine)
        options = request.model_dump()
        options.update(url=url, engine=engine)
        (directory / 'request.json').write_text(json.dumps(options))
        JOBS[key] = job
        threading.Thread(target=execute, args=(job,), daemon=True).start()
    return {'id': key}


def lookup(key):
    job = JOBS.get(key)
    if not job:
        raise HTTPException(404, 'La descarga no existe o ya caducó.')
    return job


@app.get('/jobs/{key}', dependencies=[Depends(authenticate)])
def status(key: str):
    with LOCK:
        job = lookup(key)
        return {k: job.get(k) for k in ('id', 'state', 'progress', 'message', 'title', 'format', 'engine', 'result_ext', 'count', 'speed', 'eta')}


@app.delete('/jobs/{key}', dependencies=[Depends(authenticate)])
def cancel(key: str):
    with LOCK:
        job = lookup(key)
        job.update(state='cancelled', message='Descarga cancelada.', finished=time.time())
        kill(job)
        shutil.rmtree(job['directory'], ignore_errors=True)
    return {'state': 'cancelled'}


@app.get('/files/{key}')
def download(key: str):
    # The 256-bit job ID is a short-lived download capability; never logged.
    with LOCK:
        job = lookup(key)
        if job['state'] != 'ready':
            raise HTTPException(409, 'El archivo todavía no está listo.')
        title = re.sub(r'[^\w .-]', '', job.get('title') or 'off-the-wall').strip('. ')[:100] or 'archivo'
        ext = job.get('result_ext') or job['format']
        mime = {'zip':'application/zip', 'mp3':'audio/mpeg', 'mp4':'video/mp4', 'webm':'video/webm'}.get(ext, 'application/octet-stream')
        return FileResponse(job['directory'] / f'result.{ext}', filename=f'{title}.{ext}',
                            media_type=mime,
                            headers={'Cache-Control': 'no-store', 'Referrer-Policy': 'no-referrer', 'X-Content-Type-Options': 'nosniff'})


threading.Thread(target=housekeeping, daemon=True).start()
