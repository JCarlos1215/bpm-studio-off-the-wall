# Off The Wall — gestor de descargas

Adaptación web basada en el flujo de GDownloader. Consulta `ATTRIBUTION.md` para créditos, licencia y correspondencia funcional; no es un port completo de su aplicación Java.

## Estado

La interfaz y el servidor están preparados. **El servidor no está publicado todavía.** La web mantiene `DOWNLOAD_API` vacío y permite organizar la cola, pero no iniciar descargas. No se han contratado servicios ni autorizado gastos.

## Funciones

- Motores yt-dlp, gallery-dl y spotDL. El motor automático enruta Spotify a coincidencias de YouTube, galerías a gallery-dl y audio/video a yt-dlp.
- Audio MP3, M4A/AAC, WAV, FLAC, Opus y OGG; video MP4/H.264, MKV/H.264 y WebM/VP9; MP4+MP3 en ZIP.
- Listas y galerías de hasta 20 elementos. Las galerías aceptan JPG, PNG, WebP, GIF y AVIF; no todos los tipos de archivo de gallery-dl.
- Resolución máxima 480p–2160p y selección de hasta 30/60 FPS; bitrate de audio 128–320 kbps. Sin aumento de resolución del original.
- Subtítulos disponibles y automáticos opcionales (es/en), carátulas, título/artista/álbum y descripción. El primer subtítulo se incrusta en el video; los demás y extras se entregan como archivos en ZIP.
- Dos trabajos simultáneos; cada enlace de lista cuenta como un trabajo. Máximo 12 trabajos/resultados retenidos; el cliente espera cuando el servidor está lleno.
- 30 minutos por contenido; 250 MB por archivo; 500 MB por resultado empaquetado; 20 minutos de procesamiento; 1.2 GB temporales por trabajo. Los resultados caducan 30 minutos después de terminar. Reiniciar el proceso invalida trabajos anteriores.
- Cancelación del grupo de procesos, reintentos limitados de red y velocidad limitada por trabajo.
- La web añade deduplicación, cola de 100 enlaces, prioridades, filtros, búsqueda, pausa de pendientes, importación/exportación TXT/JSON y restauración opcional en el navegador.

Spotify **no es la fuente de audio**: spotDL obtiene datos y busca una coincidencia en YouTube. Puede obtener otra versión o no encontrar coincidencia. Los resultados incluyen un manifiesto con el enlace de origen efectivo. No hay acceso a cuentas, cookies, DRM ni contenido privado.

## Desplegar

1. Publica **esta carpeta** en un alojamiento que ejecute Docker (por ejemplo, un Web Service en Render o un VPS Linux). No es un sitio estático ni una función de Netlify.
2. Usa este `Dockerfile`. Instala yt-dlp, gallery-dl, FFmpeg y Node; spotDL usa un entorno separado para evitar conflictos entre dependencias.
3. Configura `PUBLIC_DOWNLOADS=1` para el acceso sin clave desde la web y el secreto interno `DOWNLOAD_PASSWORD` con al menos 16 caracteres aleatorios y `APP_ORIGIN=https://clinquant-kelpie-5cea2b.netlify.app`, sin barra final.
4. Activa HTTPS y el health check `/health`. El puerto es `PORT` o 8000. Usa **una instancia y un worker**, porque los trabajos se guardan en memoria.
5. Para uso personal, parte de al menos 2 GB de RAM y 8 GB de espacio temporal; verifica el consumo real, especialmente con 4K y VP9. Estos son requisitos iniciales, no una garantía de rendimiento ni una recomendación de plan de pago.
6. Asigna su URL HTTPS a `DOWNLOAD_API` en el archivo `downloader-config.js` de la web y publica de nuevo en el sitio Netlify existente. **Nunca pongas la clave en los archivos públicos.**
7. Verifica enlaces propios/autorizados de cada plataforma desde el alojamiento final. Algunas plataformas bloquean IPs de centros de datos; la aplicación comunica el error y no elude bloqueos.

No requiere credenciales Spotify para el modo de metadatos público de spotDL. Si el administrador prefiere su API oficial, puede configurar `SPOTIFY_CLIENT_ID` y `SPOTIFY_CLIENT_SECRET` como secretos del servidor. Nunca se solicitan ni almacenan contraseñas Spotify.

Aceleración opcional: configura `VIDEO_ENCODER=h264_nvenc` en un alojamiento que exponga una GPU NVIDIA compatible. También se aceptan `h264_qsv` y `h264_vaapi`, sujetos al entorno. La opción «Preferir aceleración» tiene fallback CPU. El contenedor genérico no configura ni proporciona GPU; no se ha validado esa ruta con hardware real.

Documentación: https://render.com/docs/docker y https://render.com/docs/web-services

## Docker local

Crea un `.env` privado con `DOWNLOAD_PASSWORD` y `APP_ORIGIN` y ejecuta:

```sh
docker build -t otw-downloader .
docker run --rm --env-file .env -p 127.0.0.1:8000:8000 --memory=2g --cpus=2 otw-downloader
```

En VPS, usa un proxy HTTPS delante del puerto local. No se ha ejecutado la imagen en este equipo porque Docker no está instalado.

## Privacidad y red

La clave interna permanece en el servidor y nunca se envía al navegador. Los enlaces aleatorios de archivo son accesos temporales: quien los tenga podrá descargarlos hasta que caduquen. La opción Recordar cola conserva enlaces y esos accesos temporales en el navegador; se desactiva para borrar la copia local.

El proxy interno valida direcciones públicas, rechaza redes locales/reservadas y conecta a una IP ya validada. Las redirecciones vuelven a atravesar el proxy. FFmpeg/ffprobe de yt-dlp están restringidos a archivos locales/tuberías. spotDL solo resuelve metadatos/coincidencias y los archivos se descargan después con el trabajador limitado de yt-dlp. Sin shell ni argumentos de ejecutables proporcionados por usuarios.

El modo público tiene una cuota básica por IP, pero no ofrece cuentas multiusuario. Mantén límites de peticiones/CPU/memoria en el alojamiento. Para uso masivo hacen falta cuentas, cuotas por usuario y cola/almacenamiento persistentes. Los paquetes fuente no contienen claves.

## Comprobaciones

```sh
pip install -r requirements.txt httpx
python -m unittest discover -s tests -v
```

Para pruebas de conversión, instala FFmpeg o define `FFMPEG_BINARY`. Las pruebas generan un clip original y comprueban nueve formatos y un ZIP MP4+MP3. También comprueban opciones, autenticación, CORS, bloqueo de redes internas, caducidad, timeout, cancelación, empaquetado y resolución Spotify simulada. Las pruebas de UI usan un servidor controlado con audio sintético; no constituyen una prueba de descargas reales desde las plataformas.

Actualiza motores reconstruyendo la imagen y verificando las versiones fijadas en `requirements.txt` y Dockerfile. No se descargan actualizaciones automáticas de ejecutables desde el panel público.


## Descarga directa sin panel de conexión

La web ahora conecta automáticamente y solicita guardar cada resultado al terminar. El usuario no escribe una clave. Para esta modalidad configura `PUBLIC_DOWNLOADS=1` en el servidor y su URL HTTPS en `downloader-config.js`. El secreto `DOWNLOAD_PASSWORD` sigue siendo privado y no se publica. La API pública permite hasta 20 solicitudes por hora por IP observada y conserva los límites globales de trabajos y tamaño. Detrás de un proxy que agrupe las IP, la cuota puede compartirse; configura el proxy de confianza correctamente antes de un uso amplio.

La descarga automática puede ser bloqueada por el navegador, especialmente en lotes; la tarjeta conserva el botón Descargar. Los lotes y extras mantienen ZIP y los archivos contenidos tienen el formato seleccionado. El alojamiento sigue pendiente; no se ha activado una API pública ni contratado un servidor.
